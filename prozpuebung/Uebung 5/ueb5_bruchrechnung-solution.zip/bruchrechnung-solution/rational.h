#ifndef BRUCHRECHNUNG_SOLUTION_RATIONA_H
#define BRUCHRECHNUNG_SOLUTION_RATIONA_H

/* Deklarationen für Übung "Bruchrechnung" */

// Präprozessor flag. Einkommentieren zum Kürzen der Brüche.
#define KUERZEN

struct bruch_s
{
    int zaehler;
    int nenner;
};

/* Prototypen der benötigten Funktionen */

/**
 * Berechnet größten gemeinsamen Teiler (ggT) von a und b.
   Wichtig: beim Start muss gelten a >= b.
 */
int ggT(int a, int b);

/**
 * Kürzt einen Bruch und gibt diesen als Kopie zurück.
 */
struct bruch_s bruchKuerzen(struct bruch_s b);

/**
 * Berechnet die Summe zweier Brüche und gibt sie als Bruch zurück (Kopie).
 */
struct bruch_s bruchSumme(struct bruch_s z1, struct bruch_s z2);

/**
 * Berechnet die Differenz zweier Brüche und gibt sie als Bruch zurück (Kopie).
 */
struct bruch_s bruchDiff(struct bruch_s z1, struct bruch_s z2);

/**
 * Berechnet das Produkt zweier Brüche und gibt es als Bruch zurück (Kopie).
 */
struct bruch_s bruchProd(struct bruch_s z1, struct bruch_s z2);

/**
 * Berechnet den Quotient zweier Brüche und gibt ihn als Bruch zurück (Kopie).
 */
struct bruch_s bruchQuot(struct bruch_s z1, struct bruch_s z2);

#endif //BRUCHRECHNUNG_SOLUTION_RATIONA_H
