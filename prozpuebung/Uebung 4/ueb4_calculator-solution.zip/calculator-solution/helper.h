#ifndef U04_NEW_HELPER_H
#define U04_NEW_HELPER_H

double csum(double a, double b);
double cdiff(double a, double b);
double cmul(double a, double b);

double cpower(double a, unsigned int exp);

#endif //U04_NEW_HELPER_H
