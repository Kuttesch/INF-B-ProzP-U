#include <stdio.h>  	/* Standard Input/Output  z.B. scanf, printf */
#include <stdbool.h> 	/* 'bool' als Datentyp und Macros für 'true' und 'false' */
#include <time.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#include "game.h"

/*
 * Konstanten
 */
const char DISP_UNKNOWN              = '?';
const char DISP_KNOWN_IMPOSSIBLE     = '.';
const char DISP_KNOWN_ORACLE         = 'X';
const char DISP_KNOWN_GUESSED        = '!';
const char DISP_KNOWN_GUESSED_ORACLE = '$';


void guessingGame(const int oracleValueMin, const int oracleValueMax) {

    const int oracleValueRange = oracleValueMax - oracleValueMin;
    const int displaySize = oracleValueRange + 1;

    char display[displaySize + 1]; // reserve space for Null-terminator symbol
    initializeDisplay(display, displaySize);

	unsigned char retry = 'j';
    srand((unsigned int)time(0));

	do {

        // TODO: Erzeuge Zufallszahl
		int oracleValue = oracleValueMin + rand() % (oracleValueRange + 1);

		printf("Ich habe mir eine Zahl zwischen %d und %d ausgedacht. Welche ist es?\n", 
			oracleValueMin,
			oracleValueMax
		);

		guess(oracleValue, display, oracleValueMin, oracleValueMax);

		printf("Möchtest du erneut spielen? (j/n)\n");
		while(getchar() != '\n');
		scanf("%c", &retry);
		retry = tolower(retry);

	} while(retry == 'j');	
}


void guess(int oracleValue, char * display, int oracleValueMin, int oracleValueMax) {

	int remaining_guesses = N_GUESSES;
	int guessedValue = 0;
	int hint = 0;

    // TODO: Diese Funktion soll den Nutzer wiederholt nach einer Zahl fragen und das Spiel,
    //  wie im Übungsblatt gezeigt, durchführen. Die Funktion kehrt zurück, sobald der Nutzer die Zahl erraten oder
    //  seine Versuche aufgebraucht hat.

    showDisplay(display);

	do {
		scanf("%d", &guessedValue);
		hint = guessedValue - oracleValue;
		remaining_guesses--;

		if(hint < 0) {
			printf("Die ist zu klein.\n");
		} else if(hint > 0) {
			printf("Die ist zu groß.\n");
		} else {
			printf("Die ist genau richtig!\n");
		}

        updateDisplay(display, guessedValue, oracleValue, remaining_guesses, oracleValueMin, oracleValueMax);
        showDisplay(display);

	} while(hint != 0 && remaining_guesses > 0);

	if(hint != 0) {
		printf("Du hast deine %d Versuche aufgebraucht. Die korrekte Zahl war: %d.\n", N_GUESSES, oracleValue);
	} else {
		printf("Glückwunsch! Du hast nur %d von %d Versuche benötigt.\n", N_GUESSES - remaining_guesses, N_GUESSES);
	}
}


void initializeDisplay(char * display, const int sizeOfDisplay) {
    for(int i = 0; i < sizeOfDisplay; i++) {
        display[i] = DISP_UNKNOWN;
    }
    display[sizeOfDisplay] = '\0';
}

void updateDisplay(char * display, int guess, int oracle, int remainingGuesses, int oracleValueMin, int oracleValueMax) {
    unsigned long n = strlen(display);

    // TODO: Setze die Zeichen im Display entsprechend der aktuellen Spielsituation.
    //  'updateDisplay' soll nach jedem Rateversuch aus der Funktion guess heraus aufgerufen werden.

    // Based on the guess and oracle, set numbers with state UNKNOWN to state KNOWN_IMPOSSIBLE
    if(oracleValueMin <= guess && guess <= oracleValueMax) {
        for(int i = oracleValueMin; i <= oracleValueMax; i++) {
            if(display[i-oracleValueMin] == DISP_UNKNOWN) {
                if(guess > oracle && i > guess) {
                    display[i-oracleValueMin] = DISP_KNOWN_IMPOSSIBLE;
                }
                if(guess < oracle && i < guess) {
                    display[i-oracleValueMin] = DISP_KNOWN_IMPOSSIBLE;
                }
            }
        }

        display[guess-oracleValueMin] = DISP_KNOWN_GUESSED;
    }

    // If this was the user's last guess, reveal the oracle's number
    if(remainingGuesses == 0) {
        display[oracle-oracleValueMin] = DISP_KNOWN_ORACLE;
    }

    // In any case, if the guess was correct: Reveal oracle's number
    if(guess == oracle) {
        display[oracle-oracleValueMin] = DISP_KNOWN_GUESSED_ORACLE;
    }
}

void showDisplay(char * display) {
    printf("| %s |\n", display);
}


void line(int n, char c)
{
	for (int i = 0; i < n; i++) {
		printf("%c", c);
	}
	printf("\n");
}

