#include <stdio.h>
#include "loops.h"
#include <math.h>

/* Array für die Werte der Tabellenzeilen */
struct Row_s rows[MAX_LIMIT];


int main(void) {
    int grenze;

    line(77, '-');
    printf("Loops: Berechnung von einfachen Funktionen\n");
    line(77, '-');

    grenze = readLimit(MAX_LIMIT);
    calculateTable(grenze);
    printTable(grenze);

    return 0;
}


/* Gibt n mal das Zeichen c aus */
void line(int n, char c) {
    int i;

    for (i = 1; i <= n; i++) {
        printf("%c", c);
    }

    printf("\n");
}


unsigned long fac(int i) {

    unsigned long factorial = 1;

    while (i > 0) {
        factorial *= i--;
    }
    return factorial;
}


int numDigits(unsigned long x) {
    int n_digits = 1;
    unsigned long remainder = x;
    while(remainder >= 10) {
        remainder /= 10;
        n_digits++;
    }
    return n_digits;
}


int numDigits2(unsigned long x) {
    return (int)log10l((long double)x) + 1;
}


int readLimit(int cMax) {

    int limit = -1;

    do {
        // Grenze via scanf einlesen
        printf("Bitte positive obere Grenze eingeben (ganzzahlig <= %d): ", cMax);
        scanf("%d", &limit);

        // Grenze auf 1 <= limit <= cMax prüfen
        if (!(1 <= limit && limit <= cMax)) {
            printf("Fehlerhafte Eingabe. Grenze muss im Intervall [1, %d] liegen.\n", cMax);
        }
    }
        // Bei fehlerhafter Eingabe Lesevorgang und Prüfung wiederholen, ...
    while (!(1 <= limit && limit <= cMax)); //   (1 > limit || limit > cMax)

    // ...andernfalls die eingelesene Grenze zurückgeben.
    return limit;
}


void calculateTable(int limit) {

    for(int i = 1; i <= limit; i++) {
        calculateRow(i);
    }
}

void calculateRow(int i) {

    int rowIdx = i-1;

    struct Row_s row = rows[rowIdx];

    row.i = i;
    row.ApproxE = 1.0;

    for (int j = 1; j <= i; j++) {
        row.OneOverI = 1. / j;
        row.FactI = fac(j);
        row.OneOverFactI = 1. / row.FactI;
        row.CumSumOneOverI += row.OneOverI;
        row.ApproxE += row.OneOverFactI;
    }

    row.numDigitsFactI = numDigits2(row.FactI);
    rows[rowIdx] = row;
}

/*
 * Unter der Annahme, dass die Zeilenberechnungen aufsteigend
 * von i bis limit vorgenommen werden, können wir die bereits
 * berechneten Werte der vorhergehenden Zeile zur Berechnung
 * der Werte der aktuellen Zeile nutzen.
 */
void calculateRow2(int i) {
    int rowIdx = i-1;

    struct Row_s row = rows[rowIdx];

    row.i = i;
    row.OneOverI = 1. / i;

    if(i == 1) {
        row.FactI = 1;
        row.OneOverFactI = 1. / row.FactI;
        row.ApproxE = 1.0 + 1.0;  // Für i = 1: 1 / 0! + 1 / 1!
        row.CumSumOneOverI = 1.0;
    } else {
        struct Row_s prevRow = rows[rowIdx-1];
        row.FactI = prevRow.FactI * i;
        row.OneOverFactI = prevRow.OneOverFactI * (1. / i);
        row.ApproxE = prevRow.ApproxE + row.OneOverFactI;
        row.CumSumOneOverI = prevRow.CumSumOneOverI + row.OneOverI;
    }

    row.numDigitsFactI = numDigits2(row.FactI);
    rows[rowIdx] = row;
}

void printTable(int limit) {

    line(90, '-');
    printf("  i     1/i  Summe(1/i)                  i!              1/i!      Näherung e    nZiffern\n");
    line(90, '-');

    for(int r = 1; r <= limit; r++) {
        int i = r - 1;
        printf(
                "%3d  %6.4f  %9.7f %20lu  %16.14f  %14.12f %11d\n",
                rows[i].i,
                rows[i].OneOverI,
                rows[i].CumSumOneOverI,
                rows[i].FactI,
                rows[i].OneOverFactI,
                rows[i].ApproxE,
                rows[i].numDigitsFactI
        );
    }

}