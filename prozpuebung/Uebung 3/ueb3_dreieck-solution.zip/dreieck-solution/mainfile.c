//*******************************************************************
// Programm    : Dreieck                                          
// Verfasser   : Schmidt                                           
// Datum       : Urprogramm: 11.10.2012                                          
// Eingabe     : Seite + Winkel eines rechtwinkligen Dreiecks                            
// Verarbeitung: Berechnung aller Seiten und Winkel                   
// Ausgabe     : Ergebnis als Tabelle
// Änderungen  : 11.10.2012
//				 18.08.2022 (Jurgovsky)
//*******************************************************************

// Einbinden von nötigen Header-Dateien                              
#include <stdio.h>    // Standard Input/ Output  z.B. scanf, printf
#include <math.h>     // Standard-Bibliothek für math. Funktionen z.B. sqrt
#include "mainfile.h" // eigene Header-Datei mit Funktionsprototypen


int main() // Beginn Hauptprogramm          **************************
{
    // Aufgabe: Dreieck
    dreieck();

    return 0;
} //***************** Ende Hauptprogramm ***************************


// Definition der benötigten Funktionen      

void dreieck(void) {
    double a;            // Länge von Seite a
    double b;
    double c;

    double alpha_deg, alpha_rad;    // Winkel in Gradmaß und Bogenmaß
    double beta_deg, beta_rad;
    double gamma_deg, gamma_rad;

    int scanf_ret = 0;

    // Dialogeröffnung
    strich(50, '-');
    printf("Rechtwinkliges Dreieck\n");
    strich(50, '-');

    // Seite/Winkel einlesen
    do {
        printf("Bitte Laenge Seite a eingeben: ");
        scanf_ret = scanf("%lf", &a);

        if (scanf_ret != 1) {
            printf("Länge muss eine Zahl sein.\n");
            while(getchar() != '\n');
        }
        if (a <= 0.0) {
            printf("Laenge der Seite a muss positiv sein.\n");
        }
    } while (scanf_ret != 1 || a <= 0.0);

    do {
        printf("Bitte Winkel Alpha in Grad eingeben: ");
        scanf_ret = scanf("%lf", &alpha_deg);

        if (scanf_ret != 1) {
            printf("Winkel muss eine Zahl sein.\n");
            while(getchar() != '\n');
        } else {
            if (alpha_deg <= 0.0) {
                printf("Winkel Alpha muss positiv sein.\n");
            }
            if (alpha_deg >= 90.0) {
                printf("Winkel Alpha muss kleiner 90° sein.\n");
            }
        }
    } while (scanf_ret != 1 || alpha_deg <= 0.0 || alpha_deg >= 90.0);

    // Berechnung aller Seiten und Winkel
    // speichern aller Ergebnisse in einer neuen Variable
    gamma_deg = 90.0;
    beta_deg = 180.0 - (alpha_deg + gamma_deg);

    alpha_rad = deg2rad(alpha_deg);
    beta_rad = deg2rad(beta_deg);
    gamma_rad = deg2rad(gamma_deg);

    c = a / sin(alpha_rad);
    b = c * cos(alpha_rad);

    // abrunden aller Seiten auf die nächste ganze Zahl
    float a_floor = floor(a);
    float b_floor = floor(b);
    float c_floor = floor(c);

    // aufrunden aller Seiten auf die nächste ganze Zahl
    float a_ceil = ceil(a);
    float b_ceil = ceil(b);
    float c_ceil = ceil(c);

    // (korrektes) Runden aller Seiten auf die nächste ganze Zahl
    float a_round = round(a);
    float b_round = round(b);
    float c_round = round(c);

    // Ausgabe aller Seiten und Winkel
    printf("       2 NK-Stellen   gerundet   abgerundet   aufgerundet\n");
    strich(57, '-');

    printf("a        %10.2f %10.0f   %10.0f    %10.0f\n", a, a_round, a_floor, a_ceil);
    printf("b        %10.2f %10.0f   %10.0f    %10.0f\n", b, b_round, b_floor, b_ceil);
    printf("c        %10.2f %10.0f   %10.0f    %10.0f\n", c, c_round, c_floor, c_ceil);
    printf("Alpha (Grad)  %5.2f\n", alpha_deg);
    printf("Beta (Grad)   %5.2f\n", beta_deg);
    printf("Gamma (Grad)  %5.2f\n", gamma_deg);
    printf("Alpha (rad)   %5.3f\n", alpha_rad);
    printf("Beta (rad)    %5.3f\n", beta_rad);
    printf("Gamma (rad)   %5.3f\n", gamma_rad);
}

// Eingabe: w_deg, Winkel in Grad
// Ausgabe: w_rad, Winkel in rad
double deg2rad(double w_deg) {
    double w_rad = 0.0;
    // Grad in rad umrechnen, Ergebnis in w_rad
    w_rad = (w_deg / 180.0) * PI;

    return w_rad;
}

// gibt n mal das Zeichen c aus 
void strich(int n, char c) {
    int i;
    for (i = 1; i <= n; i++) {
        printf("%c", c);
    }

    printf("\n");
}

