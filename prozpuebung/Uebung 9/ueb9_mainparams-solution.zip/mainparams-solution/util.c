#include "util.h"
#include <stdio.h>  	/* Standard Input/Output  z.B. scanf, printf	*/
#include <string.h>  	/* Standardfunktionen für String-Operationen	*/
#include <ctype.h>      /* Standardfunktionen für Zeichentypen          */
#include <stdlib.h>     /* Standardfunktionen für Speicherverwaltung    */

void statistics(char * argv[], int argc) {

    int histogram[BINS];

    // Histogramm mit 0 initialisieren
    for(int i = 0; i < BINS; i++) {
        histogram[i] = 0;
    }

    // Histogramm erstellen
    // WICHTIG: Erstes Argument (Name des Programms) wird ignoriert
    for(int i = 1; i < argc; i++) {
        for(int j = 0; j < strlen(argv[i]); j++) {
            char c = argv[i][j];
            if(isalnum(argv[i][j])) {
                histogram[c] += 1;
            }
        }
    }

    // Histogramm ausgeben
    printf("Anzahl der Buchstaben der Parameter:\n");
    int printColumns = 0;
    for(int i = 0; i < BINS; i++) {
        if(histogram[i] > 0) {
            printf("%c: %d ", i, histogram[i]);

            printColumns++;
            if(printColumns % MAX_PRINT_COLUMNS == MAX_PRINT_COLUMNS - 1) {
                printf("\n");
            }
        }
    }
    printf("\n");
}


void reverse(char *argv[], int argc) {

    int nrWords = argc - 1;
    char* *text = (char**)calloc(nrWords, sizeof(char*));
    if(text == NULL) {
        printf("Fehler: Speicher konnte nicht alloziert werden.\n");
        exit(EXIT_FAILURE);
    }

    for (int i = 1; i < argc; ++i) {
        text[i-1] = (char*)calloc(strlen(argv[i])+1, sizeof(char));
        if(text[i-1] == NULL) {
            printf("Fehler: Speicher konnte nicht alloziert werden.\n");
            exit(EXIT_FAILURE);
        }
        strcpy(text[i-1], argv[i]);
    }

    printText(text, nrWords);
    reverseText(text, nrWords);
    printText(text, nrWords);

    deleteText(text, nrWords);
}

void reverseText(char *text[], int nrWords) {
    char * tmpWord = NULL;
    for(int i = 0; i < nrWords / 2; i++) {
        tmpWord = text[nrWords-1-i];
        text[nrWords-1-i] = text[i];
        text[i] = tmpWord;
    }
}

void printText(char *text[], int nrWords) {
    for(int i = 0; i < nrWords; i++) {
        printf("%s ", text[i]);
    }
    printf("\n");
}

void deleteText(char *text[], int nrWords) {
    if(text != NULL) {
        for (int i = 0; i < nrWords; ++i) {
            free(text[i]);
            text[i] = NULL;
        }
        free(text);
    }
}