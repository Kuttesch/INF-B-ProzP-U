/*******************************************************************/
// Programm    : Bruchrechnung                                         
// Verfasser   : Schmidt                                           
// Datum       : Urprogramm: 24.10.2012                                          
// Eingabe     : 2 rationale Zahlen                          
// Verarbeitung: Produkt, Quotient, Summe, Differenz der rationalen 
//				 Zahlen
// Ausgabe	   : Ergebnisse der jeweiligen Operationen                   
// Änderungen  : 24.10.2012
//				 18.08.2022 (Jurgovsky)
// *******************************************************************/

/* Einbinden von nötigen Header-Dateien                             */
#include <stdio.h>    /* Standard Input/ Output  z.B. scanf, printf */
#include "rational.h"

int main(void)
{
	struct bruch_s z1, z2, sum, diff, prod, quot;

	printf("Bitte Zaehler und Nenner Bruch 1 eingeben: ");
	scanf("%d %d", &z1.zaehler, &z1.nenner);
	printf("Bitte Zaehler und Nenner Bruch 2 eingeben: ");
	scanf("%d %d", &z2.zaehler, &z2.nenner);

	sum = bruchSumme(z1, z2);
	diff = bruchDiff(z1, z2);
	prod = bruchProd(z1, z2);
	quot = bruchQuot(z1, z2);

	printf("%d/%d * %d/%d = %d/%d \n", z1.zaehler, z1.nenner, z2.zaehler, z2.nenner,  prod.zaehler, prod.nenner);
	printf("%d/%d / %d/%d = %d/%d \n", z1.zaehler, z1.nenner, z2.zaehler, z2.nenner,  quot.zaehler, quot.nenner);
	printf("%d/%d + %d/%d = %d/%d \n", z1.zaehler, z1.nenner, z2.zaehler, z2.nenner,  sum.zaehler, sum.nenner);
	printf("%d/%d - %d/%d = %d/%d \n", z1.zaehler, z1.nenner, z2.zaehler, z2.nenner,  diff.zaehler, diff.nenner);
	
	return 0;
}

