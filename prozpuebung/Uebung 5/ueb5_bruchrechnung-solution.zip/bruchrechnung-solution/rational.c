#include "rational.h"


struct bruch_s bruchSumme(const struct bruch_s z1, const struct bruch_s z2)
{
    struct bruch_s sum;

    sum.zaehler = z1.zaehler * z2.nenner + z2.zaehler * z1.nenner;
    sum.nenner = z1.nenner * z2.nenner;

#ifdef KUERZEN
    sum = bruchKuerzen(sum);
#endif

    return sum;
}

struct bruch_s bruchDiff(const struct bruch_s z1, const struct bruch_s z2)
{
    struct bruch_s diff;

    diff.zaehler = z1.zaehler * z2.nenner - z2.zaehler * z1.nenner;
    diff.nenner = z1.nenner * z2.nenner;

#ifdef KUERZEN
    diff = bruchKuerzen(diff);
#endif

    return diff;
}

struct bruch_s bruchProd(const struct bruch_s z1, const struct bruch_s z2)
{
    struct bruch_s prod;

    prod.zaehler = z1.zaehler * z2.zaehler;
    prod.nenner = z1.nenner * z2.nenner;

#ifdef KUERZEN
    prod = bruchKuerzen(prod);
#endif

    return prod;
}

struct bruch_s bruchQuot(const struct bruch_s z1, const struct bruch_s z2)
{
    struct bruch_s quot;

    quot.zaehler = z1.zaehler * z2.nenner;
    quot.nenner = z1.nenner * z2.zaehler;

#ifdef KUERZEN
    quot = bruchKuerzen(quot);
#endif

    return quot;
}

/**
 * Berechnet ggT von a und b nach euklidischem Algorithmus
 * Wichtig: beim Start muss gelten: a >= b
 */
int ggT(int a, int b)
{
    int ret;

    if(b == 0) {
        ret = a;
    } else {
        ret = ggT(b, a % b);
    }

    return ret;
}

struct bruch_s bruchKuerzen(const struct bruch_s b)
{
    struct bruch_s gekb;  // gekürzter Bruch
    int ggtb;
    int z_abs = b.zaehler < 0 ? -b.zaehler : b.zaehler;
    int n_abs = b.nenner < 0 ? -b.nenner : b.nenner;

    // ggT berechnen
    if(z_abs >= n_abs) {
        ggtb = ggT(z_abs, n_abs);
    } else {
        ggtb = ggT(n_abs, z_abs);
    }

    // festellen, ob Bruch bereits gekürzt
    if(ggtb != 1) { // kann gekürzt werden
        gekb.zaehler = b.zaehler / ggtb;
        gekb.nenner = b.nenner / ggtb;
    } else {
        gekb = b;
    }

    return gekb;
}
