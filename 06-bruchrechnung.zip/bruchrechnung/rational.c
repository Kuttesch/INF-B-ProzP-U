#include "rational.h"



struct bruch_s add(struct bruch_s bruch1, struct bruch_s bruch2) {
    struct bruch_s result;

    // TODO: - Add bruch1 and bruch2
    //       - Save sum in result
    result.zaehler = 0; // Assign correct value instead
    result.nenner = 0;  // Assign correct value instead

    return result;
}


// TODO: Create function definitions for 'sub', 'mul' and 'div


/**
 * Berechnet ggT von a und b nach euklidischem Algorithmus
 * Wichtig: beim Start muss gelten: a >= b
 */
int ggT(int a, int b)
{
    int ret;

    if(b == 0) {
        ret = a;
    } else {
        ret = ggT(b, a % b);
    }

    return ret;
}

