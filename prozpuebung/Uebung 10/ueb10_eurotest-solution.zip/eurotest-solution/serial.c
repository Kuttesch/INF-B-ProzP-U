/*******************************************************************/
// Programm    : Eurotest                                               
// Verfasser   : Schmidt / Jurgovsky
// Datum       : Urprogramm: 21.11.2012                                           
// Aufgabe     : Prüfung der Seriennummer von Euro-Banknoten
// Änderungen  : 21.11.2012
// 				 14.12.2022
/*******************************************************************/

#include <stdio.h>  /* Standard Input/Output  z.B. scanf, printf */
#include <string.h>
#include "serial.h"


int charDigitToDigitValue(char c) {
	return (int)c - (int)'0';
}

int checksum(const char* serial) {

	// Format in seine Bestandteile zerlegen (optional)
	char countryCode = serial[0];
	char id[11];
	strncpy(id, serial + 1, 10);
	id[10] = '\0';
	char checkDigit = serial[11];

	// Prüfsumme berechnen
	int checksum = (int)countryCode;

	for(int i = 0; i < strlen(id); i++) {
		checksum += charDigitToDigitValue(id[i]);
	}

	checksum += charDigitToDigitValue(checkDigit);
	
	return checksum;
}


t_errcode eurotest(const char *serial) {

	printf("Serial: %s\n", serial);

	if(strlen(serial) > SNLEN) {
		return ec_zulang;
	} else if(strlen(serial) < SNLEN) {
		return ec_zukurz;
	} else {
		char countryCode = serial[0];

		char id[11];
		strncpy(id, serial + 1, 10);
		id[10] = '\0';

		char checkDigit = serial[11];

		// Prüfe countryCode in ['A', 'B', ... 'Z']
		if(!('A' <= countryCode && countryCode <= 'Z')) {
			return ec_LCfalsch;
		}

		// Prüfe Prüfziffer in ['0', '1', ... '9']
		if(!('0' <= checkDigit && checkDigit <= '9')) {
			return ec_SNkeineZiffer;
		}

		// Prüfe ID-Ziffern in ['0', '1', ... '9']
		for(int i = 0; i < strlen(id); i++) {
			if(!('0' <= id[i] && id[i] <= '9')) {
				return ec_SNkeineZiffer;
			}
		}

		// Wenn bis hierher alles OK, Prüfsumme durch Neun teilbar?
		if(checksum(serial) % 9 == 0) {
			return ec_ok;
		} else {
			return ec_pz_falsch;
		}
	}
}


void show(t_errcode error)
{
	switch(error)
	{
	case ec_ok:
		printf("Nummer ok!\n");
		break;
	case ec_pz_falsch:
		printf("Pruefziffer falsch!\n");
		break;
	case ec_zukurz:
		printf("Nummer zu kurz!\n");
		break;
	case ec_zulang:
		printf("Nummer zu lang!\n");
		break;	
	case ec_LCfalsch:
		printf("Laendercode falsch!\n");
		break;
	case ec_SNkeineZiffer:
		printf("Enthaelt Zeichen, die keine Ziffern sind!\n");
		break;
	default:
		printf("Ungueltiger Fehlercode\n");
	}
}

/**
 * Gibt n mal das Zeichen c aus
 */
void line(int n, char c) 
{
	for (int i = 0; i < n; i++) {
		printf("%c", c);
	}
	printf("\n");
}


void printSerial(const char * serial) {
    int n = strlen(serial);
    for(int i = 0; i < n; i++) {
        if(i == 0) {
            printf("\033[0;35m%c\033[0m", serial[i]);
        } else if(i == SNLEN-1) {
            printf("\033[1;30m%c\033[0m", serial[i]);
        } else {
            printf("\033[0;34m%c\033[0m", serial[i]);
        }
    }
}

