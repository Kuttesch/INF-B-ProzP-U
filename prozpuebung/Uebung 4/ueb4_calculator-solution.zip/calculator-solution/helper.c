#include "helper.h"

double csum(double a, double b) {
    return a + b;
}

double cdiff(double a, double b) {
    return a - b;
}

double cmul(double a, double b) {
    return a * b;
}

double cpower(double a, unsigned int exp) {
    if(exp <= 0) {
        return 1;
    }
    return a * cpower(a, exp - 1);
}